<template>
  <main class="noir-page">
    <h1>Noir Gallery</h1>
    <p>New York Noir visual collection coming soon.</p>

    <router-link to="/noir">Back to Noir Home</router-link>
  </main>
</template>

<style scoped>
.noir-page {
  min-height: 100vh;
  padding: 120px 8vw;
  background: #f5f1ec;
  color: #3a2e28;
  font-family: Georgia, serif;
}

h1 {
  font-size: 72px;
  font-weight: 400;
}

p,
a {
  font-size: 18px;
  color: #3a2e28;
}
</style>