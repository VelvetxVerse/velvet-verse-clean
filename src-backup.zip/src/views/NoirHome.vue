<script setup>
import NoirHeader from '../components/NoirHeader.vue'
import NoirFooter from '../components/NoirFooter.vue'
import NoirPaletteBar from '../components/NoirPaletteBar.vue'
</script>

<template>
  <main class="noir-page">
    <NoirHeader />
    <NoirPaletteBar />

    <!-- ═══════════════════════════════════════ -->
    <!-- HERO                                    -->
    <!-- ═══════════════════════════════════════ -->
    <section class="hero">
      <!-- vertical side label -->
      <div class="side-label">
        <span>BY RENATA OLIVER</span>
      </div>

      <!-- NN monogram circle -->
      <div class="monogram">
        <span>N</span>
        <span>N</span>
      </div>

      <!-- copy -->
      <div class="hero-copy">
        <span class="crown-icon">♕</span>
        <p class="eyebrow">SOFT GLAM EVENT MAKEUP ARTIST</p>
        <h1>
          Effortless beauty.<br />
          Unforgettable<br />
          <em>moments.</em> <span class="sparkle">✦</span>
        </h1>
        <div class="thin-rule">
          <span></span><span class="dot">✦</span><span></span>
        </div>
        <p class="services-line">Custom Color • Cuts • Bridal • Skin Care</p>
        <p class="hero-body">
          Elevated beauty experiences tailored to enhance your natural glow
          with precision, artistry, and luxury.
        </p>
        <div class="hero-actions">
          <router-link to="/noir/contact" class="btn-gold">BOOK YOUR EXPERIENCE →</router-link>
          <router-link to="/noir/services" class="btn-outline">EXPLORE SERVICES ⌾</router-link>
        </div>
      </div>

      <!-- decorative arc -->
      <div class="arc"></div>

      <!-- invitation badge -->
      <div class="invitation-badge">
        <span class="inv-crown">♕</span>
        <small>BY INVITATION</small>
        <em>Only</em>
        <b>✦</b>
      </div>
    </section>

    <!-- ═══════════════════════════════════════ -->
    <!-- 4-COLUMN SERVICE ICONS                  -->
    <!-- ═══════════════════════════════════════ -->
    <section class="icon-strip">
      <article>
        <div class="icon-wrap">✂</div>
        <h3>CUSTOM COLOR</h3>
        <p>Bespoke color tailored to your style and lifestyle.</p>
      </article>
      <article>
        <div class="icon-wrap">◎</div>
        <h3>CUTS</h3>
        <p>Precision cuts designed to enhance and frame.</p>
      </article>
      <article>
        <div class="icon-wrap">◇</div>
        <h3>BRIDAL</h3>
        <p>Bridal hair &amp; makeup for your most beautiful day.</p>
      </article>
      <article>
        <div class="icon-wrap">⬡</div>
        <h3>SKIN CARE</h3>
        <p>Personalized skin care for a healthy, radiant glow.</p>
      </article>
    </section>

    <!-- ═══════════════════════════════════════ -->
    <!-- ABOUT RENATA PANEL                      -->
    <!-- ═══════════════════════════════════════ -->
    <section class="about-panel">
      <div class="about-copy">
        <p class="eyebrow">ABOUT RENATA</p>
        <h2>
          Artistry. Passion.<br />
          <em>Purpose.</em> <span class="sparkle">✦</span>
        </h2>
        <p>
          With a background in both beauty and skincare, my mission is to help
          you feel your most confident through personalized, luxurious
          experiences tailored just for you.
        </p>
        <p class="signature">Renata Oliver ♡</p>
        <p class="license">LICENSED ESTHETICIAN</p>
      </div>

      <div class="about-img">
        <img src="/noir-bridal.png" alt="Renata Oliver" />
      </div>

      <div class="booking-card">
        <span class="bc-crown">♕</span>
        <p class="bc-label">BOOKING</p>
        <h3 class="bc-year">2026</h3>
        <em class="bc-season">Bridal Season</em>
        <div class="bc-rule"><span></span><span>✦</span><span></span></div>
        <p class="bc-note">NOW ACCEPTING A LIMITED NUMBER OF BRIDAL DATES.</p>
        <router-link to="/noir/contact" class="btn-gold sm">INQUIRE NOW →</router-link>
      </div>
    </section>

    <!-- ═══════════════════════════════════════ -->
    <!-- LUXURY VALUES ROW                       -->
    <!-- ═══════════════════════════════════════ -->
    <section class="values-row">
      <article>
        <div class="icon-wrap">◈</div>
        <h4>LUXURY EXPERIENCE</h4>
        <p>Elevated service in a private, relaxing space.</p>
      </article>
      <article>
        <div class="icon-wrap">⬡</div>
        <h4>PREMIUM PRODUCTS</h4>
        <p>Only the best for your hair and skin.</p>
      </article>
      <article>
        <div class="icon-wrap">◻</div>
        <h4>DISCREET &amp; PRIVATE</h4>
        <p>Your privacy and comfort are always a priority.</p>
      </article>
      <article>
        <div class="icon-wrap">◷</div>
        <h4>BY APPOINTMENT ONLY</h4>
        <p>Exclusively by invitation for a personalized touch.</p>
      </article>
    </section>

    <!-- ═══════════════════════════════════════ -->
    <!-- FOLLOW + MINI GALLERY                   -->
    <!-- ═══════════════════════════════════════ -->
    <section class="follow-section">
      <div class="follow-left">
        <p class="eyebrow">FOLLOW ALONG</p>
        <div class="social-icons">
          <a href="#" aria-label="Instagram">◎</a>
          <a href="#" aria-label="Pinterest">⊕</a>
          <a href="#" aria-label="TikTok">♪</a>
          <a href="#" aria-label="Email">✉</a>
        </div>
      </div>
      <div class="mini-gallery">
        <img src="/noir-hair.jpg" alt="" />
        <img src="/noir-flowers.png" alt="" />
        <img src="/noir-brushes.png" alt="" />
        <img src="/noir-bridal.png" alt="" />
      </div>
    </section>

    <NoirFooter />
  </main>
</template>

<style scoped>
@import url("https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300;1,400&family=Inter:wght@300;400;500&display=swap");

/* ── BASE ─────────────────────────────────────── */
.noir-page {
  --muted:     color-mix(in srgb, var(--text) 55%, transparent);
  --line:      color-mix(in srgb, var(--gold) 22%, transparent);
  --gold-soft: color-mix(in srgb, var(--gold) 72%, transparent);
  --card-bg:   color-mix(in srgb, var(--surface) 80%, transparent);

  min-height: 100vh;
  background: var(--bg);
  color: var(--text);
  font-family: "Inter", sans-serif;
  font-size: 13px;
  font-weight: 300;
  transition: background 0.45s ease, color 0.45s ease;
}

/* ── HERO ─────────────────────────────────────── */
.hero {
  position: relative;
  height: 520px;
  overflow: hidden;
  display: flex;
  align-items: center;
  background:
    linear-gradient(
      90deg,
      color-mix(in srgb, var(--bg) 96%, transparent) 0%,
      color-mix(in srgb, var(--bg) 70%, transparent) 42%,
      color-mix(in srgb, var(--bg) 4%,  transparent) 100%
    ),
    url("/noir-hair.jpg") center right / cover no-repeat;
}

/* vertical side label */
.side-label {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 32px;
  border-right: 1px solid var(--line);
  display: flex;
  align-items: center;
  justify-content: center;
}

.side-label span {
  writing-mode: vertical-rl;
  transform: rotate(180deg);
  text-transform: uppercase;
  letter-spacing: 4px;
  font-size: 7px;
  font-weight: 300;
  color: var(--muted);
  white-space: nowrap;
}

/* NN monogram */
.monogram {
  position: absolute;
  left: 52px;
  top: 50%;
  transform: translateY(-50%);
  width: 42px;
  height: 42px;
  border: 1px solid var(--line);
  border-radius: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  line-height: 1;
  font-family: "Cormorant Garamond", serif;
  font-size: 13px;
  font-weight: 400;
  color: var(--gold-soft);
  background: var(--bg);
}

/* hero copy block */
.hero-copy {
  position: relative;
  z-index: 4;
  padding-left: 110px;
  max-width: 480px;
}

.crown-icon {
  display: block;
  color: var(--gold-soft);
  font-size: 18px;
  margin-bottom: 8px;
}

.eyebrow {
  display: block;
  font-size: 9px;
  font-weight: 300;
  text-transform: uppercase;
  letter-spacing: 5px;
  color: var(--gold-soft);
  margin-bottom: 14px;
}

.hero h1 {
  font-family: "Cormorant Garamond", serif;
  font-size: clamp(28px, 2.8vw, 44px);
  font-weight: 300;
  line-height: 1.1;
  margin: 0 0 18px;
  color: var(--text);
}

.hero h1 em {
  color: var(--gold);
  font-style: italic;
}

.sparkle {
  color: var(--gold-soft);
  font-size: 0.55em;
  vertical-align: super;
}

/* thin rule with dot */
.thin-rule {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 160px;
  margin-bottom: 14px;
}

.thin-rule span:first-child,
.thin-rule span:last-child {
  flex: 1;
  height: 1px;
  background: var(--line);
  display: block;
}

.thin-rule .dot {
  color: var(--gold-soft);
  font-size: 9px;
  flex: none;
}

.services-line {
  font-family: "Cormorant Garamond", serif;
  font-size: 14px;
  font-style: italic;
  font-weight: 300;
  color: var(--gold-soft);
  margin-bottom: 10px;
}

.hero-body {
  font-size: 11px;
  font-weight: 300;
  color: var(--muted);
  line-height: 1.75;
  max-width: 300px;
  margin-bottom: 22px;
}

/* buttons */
.hero-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: nowrap;
}

.btn-gold {
  display: inline-block;
  background: var(--gold);
  color: var(--bg);
  font-size: 8px;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 2.5px;
  padding: 11px 22px;
  text-decoration: none;
  white-space: nowrap;
  transition: opacity 0.3s ease;
}

.btn-gold:hover { opacity: 0.82; }

.btn-gold.sm { padding: 10px 18px; }

.btn-outline {
  display: inline-block;
  color: var(--text);
  font-size: 8px;
  font-weight: 400;
  text-transform: uppercase;
  letter-spacing: 2.5px;
  padding: 10px 20px;
  border: 1px solid var(--line);
  text-decoration: none;
  white-space: nowrap;
  transition: 0.3s ease;
}

.btn-outline:hover {
  border-color: var(--gold);
  color: var(--gold);
}

/* decorative arc */
.arc {
  position: absolute;
  left: 34%;
  top: -100px;
  width: 340px;
  height: 740px;
  border-right: 1px solid var(--line);
  border-radius: 50%;
  opacity: 0.4;
  pointer-events: none;
}

/* invitation badge */
.invitation-badge {
  position: absolute;
  right: 64px;
  top: 48px;
  width: 90px;
  height: 90px;
  border: 1px solid var(--line);
  outline: 1px solid color-mix(in srgb, var(--gold) 12%, transparent);
  outline-offset: 5px;
  border-radius: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  gap: 1px;
  color: var(--gold-soft);
}

.inv-crown { font-size: 12px; }

.invitation-badge small {
  text-transform: uppercase;
  letter-spacing: 1.5px;
  font-size: 6px;
  font-weight: 300;
}

.invitation-badge em {
  font-family: "Cormorant Garamond", cursive;
  font-size: 20px;
  font-weight: 300;
  font-style: italic;
  line-height: 1;
}

.invitation-badge b {
  font-size: 8px;
  font-weight: 300;
  opacity: 0.6;
}

/* ── ICON STRIP ───────────────────────────────── */
.icon-strip {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  border-top: 1px solid var(--line);
  border-bottom: 1px solid var(--line);
  background: var(--surface);
  margin: 0 40px;
  border-radius: 0 0 10px 10px;
}

.icon-strip article,
.values-row article {
  text-align: center;
  padding: 24px 16px;
  border-right: 1px solid var(--line);
}

.icon-strip article:last-child,
.values-row article:last-child {
  border-right: none;
}

.icon-wrap {
  font-size: 22px;
  color: var(--gold-soft);
  margin-bottom: 10px;
  line-height: 1;
}

.icon-strip h3,
.values-row h4 {
  text-transform: uppercase;
  letter-spacing: 3px;
  font-size: 8px;
  font-weight: 500;
  color: var(--gold);
  margin-bottom: 6px;
}

.icon-strip p,
.values-row p {
  color: var(--muted);
  font-size: 10px;
  line-height: 1.6;
  font-weight: 300;
}

/* ── ABOUT PANEL ──────────────────────────────── */
.about-panel {
  display: grid;
  grid-template-columns: 34% 32% 34%;
  align-items: center;
  padding: 40px 48px;
  margin: 28px 40px 0;
  border: 1px solid var(--line);
  background: var(--surface);
  border-radius: 10px 10px 0 0;
  gap: 0;
}

.about-copy .eyebrow { margin-bottom: 12px; }

.about-copy h2 {
  font-family: "Cormorant Garamond", serif;
  font-size: clamp(24px, 2.6vw, 38px);
  font-weight: 300;
  line-height: 1.1;
  margin: 0 0 16px;
}

.about-copy h2 em {
  color: var(--gold);
  font-style: italic;
}

.about-copy p {
  color: var(--muted);
  font-size: 11px;
  line-height: 1.8;
  font-weight: 300;
  max-width: 300px;
  margin-bottom: 12px;
}

.signature {
  font-family: "Cormorant Garamond", cursive;
  font-style: italic;
  font-size: 20px !important;
  font-weight: 400;
  color: var(--text) !important;
  margin-top: 14px;
  margin-bottom: 4px;
}

.license {
  font-size: 8px !important;
  text-transform: uppercase;
  letter-spacing: 3px;
  color: var(--muted) !important;
  font-weight: 300;
}

.about-img {
  height: 260px;
  border: 1px solid var(--line);
  overflow: hidden;
}

.about-img img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

/* booking card */
.booking-card {
  margin-left: 32px;
  padding: 28px 22px;
  border: 1px solid var(--line);
  text-align: center;
  background: color-mix(in srgb, var(--bg) 60%, transparent);
}

.bc-crown {
  display: block;
  color: var(--gold-soft);
  font-size: 22px;
  margin-bottom: 6px;
}

.bc-label {
  text-transform: uppercase;
  letter-spacing: 3px;
  font-size: 8px;
  color: var(--muted);
  font-weight: 300;
  margin-bottom: 4px;
}

.bc-year {
  font-family: "Cormorant Garamond", serif;
  font-size: 44px;
  font-weight: 300;
  color: var(--text);
  margin: 4px 0;
  line-height: 1;
}

.bc-season {
  font-family: "Cormorant Garamond", serif;
  font-size: 22px;
  font-style: italic;
  font-weight: 300;
  color: var(--gold);
  display: block;
  margin-bottom: 8px;
}

.bc-rule {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 10px 0;
  color: var(--gold-soft);
  font-size: 8px;
}

.bc-rule span:first-child,
.bc-rule span:last-child {
  flex: 1;
  height: 1px;
  background: var(--line);
  display: block;
}

.bc-note {
  font-size: 8px;
  text-transform: uppercase;
  letter-spacing: 1.5px;
  color: var(--muted);
  line-height: 1.65;
  font-weight: 300;
  margin-bottom: 16px;
}

/* ── VALUES ROW ───────────────────────────────── */
.values-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  margin: 0 40px;
  border: 1px solid var(--line);
  border-top: none;
  background: var(--surface);
  border-radius: 0 0 10px 10px;
}

/* ── FOLLOW SECTION ───────────────────────────── */
.follow-section {
  display: grid;
  grid-template-columns: 180px 1fr;
  gap: 28px;
  align-items: center;
  margin: 28px 40px 48px;
  padding: 28px 32px;
  border: 1px solid var(--line);
  background: var(--surface);
  border-radius: 10px;
}

.follow-left .eyebrow { margin-bottom: 12px; }

.social-icons {
  display: flex;
  gap: 14px;
  font-size: 18px;
  color: var(--gold-soft);
}

.social-icons a {
  color: var(--gold-soft);
  text-decoration: none;
  transition: color 0.3s ease;
}

.social-icons a:hover { color: var(--gold); }

.mini-gallery {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 8px;
}

.mini-gallery img {
  width: 100%;
  height: 100px;
  object-fit: cover;
  border: 1px solid var(--line);
}

/* ── RESPONSIVE ───────────────────────────────── */
@media (max-width: 960px) {
  .hero { height: auto; min-height: 460px; }
  .hero-copy { padding: 60px 20px 60px 60px; max-width: 100%; }
  .invitation-badge { display: none; }

  .icon-strip,
  .values-row { grid-template-columns: repeat(2, 1fr); margin: 0 20px; }

  .about-panel {
    grid-template-columns: 1fr;
    margin: 20px 20px 0;
    padding: 28px 20px;
  }

  .booking-card { margin-left: 0; margin-top: 20px; }

  .values-row { margin: 0 20px; }

  .follow-section {
    grid-template-columns: 1fr;
    margin: 20px 20px 36px;
  }

  .mini-gallery { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 600px) {
  .icon-strip,
  .values-row { grid-template-columns: 1fr; }
  .hero-actions { flex-wrap: wrap; }
  .mini-gallery { grid-template-columns: repeat(2, 1fr); }
}
</style>
